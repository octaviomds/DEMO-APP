<?php $__env->startComponent($typeForm, get_defined_vars()); ?>
    <?php if(strlen($value) > 0): ?>
        <p <?php echo e($attributes); ?>>
            <?php echo e($value); ?>

        </p>
    <?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/georgijkuliasvili/Dropbox/code/everbloom/backend/vendor/orchid/platform/resources/views/fields/label.blade.php ENDPATH**/ ?>