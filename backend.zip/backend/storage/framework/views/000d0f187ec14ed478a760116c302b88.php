<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" class="1" viewBox="0 0 16 16" role="img" path="bs.three-dots-vertical" componentName="orchid-icon">
  <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0"></path>
</svg>
<?php /**PATH /Users/georgijkuliasvili/Dropbox/code/everbloom/backend/storage/framework/views/01923c0aead0752e78a808c8b60090b2.blade.php ENDPATH**/ ?>